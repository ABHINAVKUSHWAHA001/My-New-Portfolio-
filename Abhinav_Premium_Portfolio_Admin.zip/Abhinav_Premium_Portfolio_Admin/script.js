document.addEventListener("DOMContentLoaded", () => {
  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];
  const read = (key) => localStorage.getItem("akp_" + key);

  // Text and contact settings saved by admin.html
  const textSettings = {
    heroTitle: "#myName",
    heroSubtitle: ".eyebrow",
    heroCopy: ".hero-copy",
    aboutCopy: ".about-copy .large-copy"
  };

  Object.entries(textSettings).forEach(([key, selector]) => {
    const value = read(key);
    const element = $(selector);
    if (value && element) {
      if (key === "heroTitle") {
        // Keep heading text safe; admin text is plain text, not HTML.
        element.textContent = value;
      } else {
        element.textContent = value;
      }
    }
  });

  const count = read("projectCount");
  const countElement = $(".hero-stats div:first-child b");
  if (count && countElement) countElement.textContent = count;

  const email = read("email");
  if (email) {
    $$('a[href^="mailto:"]').forEach((link) => {
      link.href = "mailto:" + email;
      const label = link.querySelector("b");
      if (label) label.textContent = email;
    });
  }

  const linkedin = read("linkedin");
  if (linkedin && isHttpUrl(linkedin)) {
    $$('a[href*="linkedin.com/in/"]').forEach((link) => {
      link.href = linkedin;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
    });
  }

  const phone = (read("whatsapp") || "916391348330").replace(/\D/g, "");
  $$('a[href*="wa.me/"]').forEach((link) => {
    link.href = "https://wa.me/" + phone + "?text=" +
      encodeURIComponent("Hello Abhinav, I visited your portfolio.");
    link.target = "_blank";
    link.rel = "noopener noreferrer";
  });

  // Animated letter-by-letter name, followed by a soft neon glow.
  const nameHeading = $("#myName");
  if (nameHeading) {
    const fullName = nameHeading.textContent.trim() || "Abhinav Kushwaha";
    nameHeading.textContent = "";
    [...fullName].forEach((letter, index) => {
      const span = document.createElement("span");
      span.textContent = letter === " " ? "\u00a0" : letter;
      span.style.animationDelay = `${index * 0.075}s`;
      nameHeading.appendChild(span);
    });
    const animationTime = fullName.length * 75 + 650;
    window.setTimeout(() => {
      nameHeading.textContent = fullName;
      nameHeading.classList.add("glow");
    }, animationTime);
  }

  // Render any number of projects added in the Admin Panel.
  const projectGrid = $("#projectGrid");
  const defaultProjects = [
    {title:"Hospital Management System",url:"https://hospitalmanagementsystems00.netlify.app/",description:"A web project focused on a healthcare management experience.",category:"Web Development",tag:"HEALTHCARE / WEB APP",style:"hospital-art",symbol:"+"},
    {title:"FitLife — Fitness Website",url:"https://fittlifes.netlify.app/",description:"A fitness-focused web experience built around healthy routines and activity.",category:"Web Development",tag:"FITNESS / WELLNESS",style:"fitness-art",symbol:"✳"},
    {title:"ZemBow — Online Shopping",url:"https://zembowabhishoppingcom.netlify.app/",description:"A clothing and shopping website project with a fashion-focused storefront.",category:"E-commerce",tag:"FASHION / E-COMMERCE",style:"store-art",symbol:"Z"}
  ];
  let projects = defaultProjects;
  try {
    const saved = read("projects");
    if (saved) { const parsed = JSON.parse(saved); if (Array.isArray(parsed)) projects = parsed; }
  } catch (error) { console.warn("Could not read saved project list.", error); }
  if (projectGrid) {
    projectGrid.innerHTML = "";
    projects.forEach((project, index) => {
      const card = document.createElement("a");
      card.className = "project-card reveal";
      card.href = isHttpUrl(project.url || "") ? project.url : "#projects";
      card.target = "_blank"; card.rel = "noopener noreferrer";
      const art = document.createElement("div");
      art.className = "project-art " + (project.style || "custom-art");
      if (project.image) {
        art.style.backgroundImage = `linear-gradient(180deg,transparent,rgba(10,8,25,.3)),url("${project.image}")`;
        art.style.backgroundSize = "cover"; art.style.backgroundPosition = "center";
      } else {
        const symbol = document.createElement("div");
        symbol.className = "custom-project-symbol"; symbol.textContent = project.symbol || "✦"; art.appendChild(symbol);
      }
      const tag = document.createElement("span"); tag.textContent = project.tag || "PROJECT / WEB"; art.appendChild(tag);
      const info = document.createElement("div"); info.className = "project-info";
      const meta = document.createElement("div"); meta.className = "project-meta";
      const number = document.createElement("span"); number.textContent = "PROJECT " + String(index+1).padStart(2,"0");
      const live = document.createElement("span"); live.textContent = "↗ LIVE SITE"; meta.append(number,live);
      const heading = document.createElement("h3"); heading.textContent = project.title || "Untitled project";
      const description = document.createElement("p"); description.textContent = project.description || "Project details coming soon.";
      const bottom = document.createElement("div"); bottom.className = "project-bottom";
      const category = document.createElement("span"); category.textContent = project.category || "Project";
      const open = document.createElement("b"); open.textContent = "Open project ↗"; bottom.append(category,open);
      info.append(meta,heading,description,bottom); card.append(art,info); projectGrid.appendChild(card);
    });
    if ("IntersectionObserver" in window) {
      const projectReveal = new IntersectionObserver((entries, observer) => entries.forEach(entry => { if(entry.isIntersecting){entry.target.classList.add("visible");observer.unobserve(entry.target);} }), {threshold:.12});
      $$("#projectGrid .reveal").forEach(el => projectReveal.observe(el));
    } else { $$("#projectGrid .reveal").forEach(el => el.classList.add("visible")); }
  }

  // Profile image upload saved from the Admin Panel.
  const profileImage = read("profileImage");
  if (profileImage) {
    $$(".profile-photo").forEach((img) => { img.src = profileImage; });
  }

  // Theme color customization.
  const accent = read("themeAccent");
  const background = read("themeBackground");
  const surface = read("themeSurface");
  if (accent) document.documentElement.style.setProperty("--admin-accent", accent);
  if (background) {
    document.body.style.backgroundColor = background;
    document.documentElement.style.setProperty("--admin-background", background);
  }
  if (surface) document.documentElement.style.setProperty("--admin-surface", surface);
  if (accent) {
    document.documentElement.style.setProperty("--mint", accent);
    document.documentElement.style.setProperty("--mint-dark", accent);
    document.documentElement.style.setProperty("--purple", accent);
  }

  function isHttpUrl(value) {
    try {
      const parsed = new URL(value);
      return parsed.protocol === "https:" || parsed.protocol === "http:";
    } catch {
      return false;
    }
  }

  // Sticky header.
  const header = $(".header");
  if (header) {
    const updateHeader = () => header.classList.toggle("scrolled", window.scrollY > 10);
    updateHeader();
    window.addEventListener("scroll", updateHeader, { passive: true });
  }

  // Mobile navigation.
  const menuButton = $(".menu-btn");
  const navigation = $("#navLinks");
  const navLinks = $$(".nav-links a");
  if (menuButton && navigation) {
    menuButton.addEventListener("click", () => {
      const isOpen = navigation.classList.toggle("open");
      menuButton.textContent = isOpen ? "✕" : "☰";
      menuButton.setAttribute("aria-expanded", String(isOpen));
    });
    navLinks.forEach((link) => link.addEventListener("click", () => {
      navigation.classList.remove("open");
      menuButton.textContent = "☰";
      menuButton.setAttribute("aria-expanded", "false");
    }));
  }

  // Scroll reveal animation and active navigation.
  const sections = $$("main section[id]");
  if ("IntersectionObserver" in window) {
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    $$(".reveal").forEach((element) => revealObserver.observe(element));

    const activeObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          navLinks.forEach((link) => link.classList.toggle(
            "active", link.hash === "#" + entry.target.id
          ));
        }
      });
    }, { rootMargin: "-35% 0px -55% 0px" });
    sections.forEach((section) => activeObserver.observe(section));
  } else {
    $$(".reveal").forEach((element) => element.classList.add("visible"));
  }

  const yearElement = $("#year");
  if (yearElement) yearElement.textContent = new Date().getFullYear();

  // Contact form opens WhatsApp with a prepared message.
  const contactForm = $("#contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!contactForm.reportValidity()) return;
      const name = $("#name")?.value.trim() || "";
      const visitorEmail = $("#email")?.value.trim() || "";
      const message = $("#message")?.value.trim() || "";
      const whatsappMessage = `Hello Abhinav, my name is ${name}.\nEmail: ${visitorEmail}\n\n${message}`;
      const whatsappUrl = "https://wa.me/" + phone + "?text=" +
        encodeURIComponent(whatsappMessage);
      const hint = $("#formHint");
      if (hint) hint.textContent = "WhatsApp is opening. Press Send in WhatsApp to deliver your message.";
      window.open(whatsappUrl, "_blank", "noopener,noreferrer");
    });
  }
});
