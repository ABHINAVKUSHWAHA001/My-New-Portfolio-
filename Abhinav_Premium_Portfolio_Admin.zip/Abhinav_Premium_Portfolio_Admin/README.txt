ABHINAV KUSHWAHA — PREMIUM PORTFOLIO
====================================

FILES
-----
index.html  Main portfolio homepage
style.css   Premium design, responsive layout and animations
script.js   Navigation, scroll reveal, contact form and admin settings
admin.html  Password-gated local admin editor
profile.jpg Your profile photo
README.txt  Setup and security notes


RUN LOCALLY
-----------
1. Extract the ZIP.
2. Open the extracted folder in Visual Studio Code.
3. Keep all files in the same folder.
4. Open index.html with VS Code Live Server.
5. Open admin.html to edit portfolio details.


ADMIN LOGIN
-----------
Default password: Abhinav@2026

After login, you can edit:
- Hero title and description
- About section
- Project count
- Email, WhatsApp and LinkedIn
- Unlimited projects: add new projects later, edit details, or remove projects
- Project titles, descriptions and URLs
- Profile picture
- Project cover images
- Accent, background and surface colors
- Admin password (change it from the panel)

Image uploads should be under 1 MB for localStorage reliability.
Use compressed JPG, PNG or WebP images.


IMPORTANT SECURITY LIMITATION
-----------------------------
This is a static front-end website. The password gate is only a
basic deterrent; it is NOT secure authentication. A visitor who can
inspect the source files or browser storage can bypass it.

Do not store private information in this panel. For a genuinely
protected admin page on a public website, use server-side
authentication and a backend or trusted CMS.

Admin edits are stored in the current browser's localStorage.
They do not automatically update Netlify or other visitors' browsers.
To publish changes, update/redeploy the website files or connect a CMS.


ANIMATIONS
----------
Animal animation has been removed. Scroll reveal, hover effects,
floating visual elements and smooth navigation remain.


PROJECT LINKS
-------------
LinkedIn:
https://www.linkedin.com/in/abhinav0099/

Hospital Management System:
https://hospitalmanagementsystems00.netlify.app/

FitLife:
https://fittlifes.netlify.app/

ZemBow:
https://zembowabhishoppingcom.netlify.app/


CONTACT
-------
WhatsApp: +91 63913 48330
Email: abhinavkush6391@gmail.com

The contact form opens WhatsApp with a pre-filled message.
The visitor must press Send to send the message.
